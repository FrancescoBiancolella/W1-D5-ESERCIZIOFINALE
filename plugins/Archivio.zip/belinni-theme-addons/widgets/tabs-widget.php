<?php
/**
 * @package     belinni
 * @version     1.1.5
 * @author      Pixelshow
 * @link        http://pixel-show.com
 * @copyright   Copyright (c) 2017 Pixelshow
 * @license     GPL v2
 *
 * Plugin Name: Tabs
 */

add_action('widgets_init', 'pxs_register_tabs_widget');

function pxs_register_tabs_widget()
{
    register_widget('pxs_tabs');
}

class pxs_tabs extends WP_Widget
{

    /**
     * Widget setup.
     */
    function __construct()
    {
        /* Widget settings. */
        $widget_ops = array('classname' => 'widget-tabs', 'description' => esc_html__('Displays tabs of recent, popular posts and comments in sidebar.', 'belinni'));

        /* Create the widget. */
        parent::__construct('pxs_tabs', esc_html__('Belinni: Widget Tabs', 'belinni'), $widget_ops);
    }

    /**
     *display the widget on the screen.
     */
    function widget($args, $instance)
    {
        extract($args);

        echo($before_widget);

        /* if ( $title )
        echo $before_title . $title . $after_title; */
        $entries_display = $instance['entries_display'];
        $meta_ar = array('author', 'date');

        if ((!isset($entries_display)) || ($entries_display == NULL)) {
            $entries_display = '5';
        }

        $args_latest = array(
            'post_type' => 'post',
            'ignore_sticky_posts' => 1,
            'posts_per_page' => $entries_display
        );
        $recent_post = $instance['recent-post-tab'];
        $popular_post = $instance['popular-post-tab'];
        $recent_comment = $instance['recent-comment-tab'];

        if (($recent_post != 'on' && $popular_post != 'on')
            || ($recent_post != 'on' && $recent_comment != 'on')
            || $recent_comment != 'on' && $popular_post != 'on'
        ) {
            $full_tab = null;
        } else {
            $full_tab = 'on';
        }
        $uid = uniqid();
        ?>
        <div class="widget-tabs-title-container">
            <ul class="widget-tab-titles">
                <?php if ($recent_post == 'on') { ?>
                    <li class="active"><h3><a
                                href="#widget-tab1-content-<?php echo($uid); ?>"><?php $full_tab ? esc_html_e('Recent', 'belinni') : esc_html_e('Latest Posts', 'belinni'); ?></a>
                        </h3></li>
                <?php } ?>
                <?php if ($popular_post == 'on') { ?>
                    <li class="<?php if ($recent_post != 'on') {
                        echo "active";
                    } ?>"><h3><a
                                href="#widget-tab2-content-<?php echo($uid); ?>"><?php $full_tab ? esc_html_e('Popular', 'belinni') : esc_html_e('Popular Posts', 'belinni'); ?></a>
                        </h3></li>
                <?php } ?>
                <?php if ($recent_comment == 'on') { ?>
                    <li class="<?php if (($recent_post != 'on') && ($popular_post != 'on')) {
                        echo "active";
                    } ?>"><h3><a
                                href="#widget-tab3-content-<?php echo($uid); ?>"><?php $full_tab ? esc_html_e('Comments', 'belinni') : esc_html_e('Latest Comments', 'belinni'); ?></a>
                        </h3></li>
                <?php } ?>
            </ul>
        </div>
        <div class="widget-tabs-content">
            <?php if ($recent_post == 'on') { ?>
                <div id="widget-tab1-content-<?php echo($uid); ?>" class="tab-content" <?php if ($recent_post == 'on') {
                    echo 'style="display: block;"';
                } ?>>
                    <?php $latest_posts = new WP_Query($args_latest); ?>
                    <?php if ($latest_posts->have_posts()) : ?>

                        <ul class="list post-list">
                            <?php while ($latest_posts->have_posts()) : $latest_posts->the_post();
                                $post_id = get_the_ID(); ?>
                                <li>
                                    <div class="side-item">

                                        <?php if ((function_exists('has_post_thumbnail')) && (has_post_thumbnail())) : ?>
                                            <div class="side-image">
                                                <a href="<?php echo get_permalink() ?>"
                                                   rel="bookmark"><?php the_post_thumbnail('belinni-latest-side', array('class' => 'side-item-thumb')); ?></a>
                                            </div>
                                        <?php endif; ?>
                                        <div class="side-item-text">
                                            <h6><a href="<?php echo get_permalink() ?>"
                                                   rel="bookmark"><?php echo pixelshow_string_limit_words(get_the_title(), 5); ?>...</a></h6>
                                            <div class="post-entry">
                                                <p><?php echo pixelshow_string_limit_words(get_the_excerpt(), 5); ?>&hellip;</p>
                                            </div>
                                            <span class="date"><?php the_time(get_option('date_format')); ?></span>
                                        </div>
                                    </div>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            <?php } ?>

            <?php if ($popular_post == 'on') { ?>
                <div id="widget-tab2-content-<?php echo($uid); ?>" class="tab-content" <?php if ($recent_post != 'on') {
                    echo 'style="display: block;"';
                } ?>>
                    <?php
                    $args_popular = array(
                        'post_type' => 'post',
                        'ignore_sticky_posts' => 1,
                        'posts_per_page' => $entries_display,
                        'orderby' => 'comment_count'
                    );
                    ?>
                    <?php $latest_posts = new WP_Query($args_popular); ?>
                    <?php if ($latest_posts->have_posts()) : ?>
                        <ul class="list post-list">
                            <?php while ($latest_posts->have_posts()) : $latest_posts->the_post();
                                $post_id = get_the_ID(); ?>
                                <li>
                                    <div class="side-item">

                                        <?php if ((function_exists('has_post_thumbnail')) && (has_post_thumbnail())) : ?>
                                            <div class="side-image">
                                                <a href="<?php echo get_permalink() ?>"
                                                   rel="bookmark"><?php the_post_thumbnail('belinni-latest-side', array('class' => 'side-item-thumb')); ?></a>
                                            </div>
                                        <?php endif; ?>
                                        <div class="side-item-text">
                                            <h6><a href="<?php echo get_permalink() ?>"
                                                   rel="bookmark"><?php the_title(); ?></a></h6>
                                            <div class="post-entry">
                                                <p><?php echo pixelshow_string_limit_words(get_the_excerpt(), 5); ?>&hellip;</p>
                                            </div>
                                            <span class="date"><?php the_time(get_option('date_format')); ?></span>
                                        </div>
                                    </div>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            <?php } ?>

            <?php if ($recent_comment == 'on') { ?>
                <div id="widget-tab3-content-<?php echo($uid); ?>"
                     class="tab-content" <?php if (($recent_post != 'on') && ($popular_post != 'on')) {
                    echo 'style="display: block;"';
                } ?>>
                    <?php
                    $args = array(
                        'status' => 'approve',
                        'number' => $entries_display
                    );
                    $comments = get_comments($args);
                    if (!empty($comments)) :
                        echo '<ul>';
                        foreach ($comments as $comment) :
                            echo '<li><a href="' . get_permalink($comment->comment_post_ID) . '#comment-' . $comment->comment_ID . '">' . $comment->comment_author . ' on ' . get_the_title($comment->comment_post_ID) . '</a></li>';
                        endforeach;
                        echo '</ul>';
                    endif; ?>
                </div>
            <?php } ?>
        </div>
        <?php

        /* After widget (defined by themes). */
        echo($after_widget);
    }

    /**
     * update widget settings
     */
    function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['entries_display'] = strip_tags($new_instance['entries_display']);
        $instance['recent-post-tab'] = $new_instance['recent-post-tab'];
        $instance['popular-post-tab'] = $new_instance['popular-post-tab'];
        $instance['recent-comment-tab'] = $new_instance['recent-comment-tab'];
        return $instance;
    }

    /**
     * Displays the widget settings controls on the widget panel.
     * Make use of the get_field_id() and get_field_name() function
     * when creating your form elements. This handles the confusing stuff.
     */
    function form($instance)
    {
        $defaults = array('entries_display' => 5, 'recent-post-tab' => 'on', 'popular-post-tab' => 'on', 'recent-comment-tab' => 'on'
        );
        $instance = wp_parse_args((array)$instance, $defaults);
        ?>
        <p><input id="<?php echo $this->get_field_id('recent-post-tab'); ?>" type="checkbox"
                  name="<?php echo $this->get_field_name('recent-post-tab'); ?>" <?php checked($instance['recent-post-tab'], 'on'); ?>/>
            <label
                for="<?php echo $this->get_field_id('recent-post-tab'); ?>"><?php esc_html_e('Recent posts tab', 'belinni'); ?></label>
        </p>

        <p><input id="<?php echo $this->get_field_id('popular-post-tab'); ?>" type="checkbox"
                  name="<?php echo $this->get_field_name('popular-post-tab'); ?>" <?php checked($instance['popular-post-tab'], 'on'); ?>/>
            <label
                for="<?php echo $this->get_field_id('popular-post-tab'); ?>"><?php esc_html_e('Popular posts tab', 'belinni'); ?></label>
        </p>

        <p><input id="<?php echo $this->get_field_id('recent-comment-tab'); ?>" type="checkbox"
                  name="<?php echo $this->get_field_name('recent-comment-tab'); ?>" <?php checked($instance['recent-comment-tab'], 'on'); ?>/>
            <label
                for="<?php echo $this->get_field_id('recent-comment-tab'); ?>"><?php esc_html_e('Recent comments tab', 'belinni'); ?></label>
        </p>

        <p><label
                for="<?php echo $this->get_field_id('entries_display'); ?>"><strong><?php esc_html_e('Number of entries to display: ', 'belinni'); ?></strong></label>
            <input type="text" id="<?php echo $this->get_field_id('entries_display'); ?>"
                   name="<?php echo $this->get_field_name('entries_display'); ?>"
                   value="<?php echo $instance['entries_display']; ?>" style="width:100%;"/></p>

        <?php
    }
}

?>
