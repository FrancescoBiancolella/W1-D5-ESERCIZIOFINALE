<?php
/**
 * @copyright 2022 Snap Creek LLC
 * Class for all IO operations
 */
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
if (! defined('DUPLICATOR_VERSION')) {
    exit;
}

/**
 * This class is deprecated.  Please use:
 * Duplicator\Libs\Snap\SnapIO
 */
class DUP_IO
{
    /* !!DO NOT IMPLMENT HERE!! */
}
